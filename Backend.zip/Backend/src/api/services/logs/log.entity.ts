export interface Log {
    id?: string;
    ipAddress: string;
    date: Date;
    result: boolean;
    description: string;
}